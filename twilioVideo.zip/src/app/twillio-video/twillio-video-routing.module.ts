import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { TwillioVideoPage } from './twillio-video.page';

const routes: Routes = [
  {
    path: '',
    component: TwillioVideoPage
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class TwillioVideoPageRoutingModule {}
