import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { TwillioVideoPageRoutingModule } from './twillio-video-routing.module';

import { TwillioVideoPage } from './twillio-video.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    TwillioVideoPageRoutingModule
  ],
  declarations: [TwillioVideoPage]
})
export class TwillioVideoPageModule {}
