import { HttpClient } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
declare let window: any;
@Component({
  selector: 'app-twillio-video',
  templateUrl: './twillio-video.page.html',
  styleUrls: ['./twillio-video.page.scss'],
})
export class TwillioVideoPage {
  userForm: {
    username: '',
    roomId: Number,
    token: ''
  }
  isMeeting = false
  constructor(private http: HttpClient) {
    this.userForm = {
      username: '',
      roomId: null,
      token: ''
    }

  }
  // async startVideo() {
  //   this.twillioService.presentLoading()
  //   this.twillioService.getToken(this.userForm).then(data => {
  //     console.log('data', data)
  //     this.twillioService.DismissLoading()
  //     if (data.data) {
  //       this.userForm.token = data.data
  //       this.goIntoMeeting(data.data, this.userForm.roomId)
  //     }
  //   })
  //     .catch(error => {
  //       console.log('error', error)

  //       this.twillioService.DismissLoading()
  //       let msg = 'Oops! Something went wrong, try again!'
  //       this.twillioService.presentToast(msg)
  //     });

  // }

  // goIntoMeeting(token, room) {
  //   this.isMeeting = true
  //   let msg = 'Call Started Successfully'
  //   this.twillioService.presentToast(msg)
  //   window.twiliovideo.openRoom(token, room)
  // }


  // exitMeeting() {
  //   this.isMeeting = false
  //   if (this.userForm.token && this.userForm.roomId) {
  //     window.twiliovideo.closeRoom(this.userForm.token, this.userForm.roomId).then(res => {
  //       let msg = 'You Left the Meeting Successfully'
  //       this.twillioService.presentToast(msg)
  //       this.userForm = {
  //         username: '',
  //         roomId: null,
  //         token: ''
  //       }
  //     })
  //   }

  // }

}
