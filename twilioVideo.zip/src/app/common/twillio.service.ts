import { Injectable, ElementRef, Renderer2, RendererFactory2, ViewChild } from '@angular/core';
import { Observable } from 'rxjs';
import { connect } from 'twilio-video';
import { BehaviorSubject } from 'rxjs';
import { Router } from '@angular/router';
import { HttpClient } from '@angular/common/http';
import { LoadingController } from '@ionic/angular';
@Injectable()
export class TwilioService {
  // remoteVideo: ElementRef;
  // localVideo: ElementRef;
  @ViewChild('localVideo') localVideo: ElementRef;
  @ViewChild('remoteVideo') remoteVideo: ElementRef;
  previewing: boolean;
  msgSubject = new BehaviorSubject("");
  roomObj: any;
  microphone = true;
  roomParticipants;
  renderer: Renderer2;
  loading: any
  constructor(
    private http: HttpClient,
    private router: Router,
    private rendererFactory: RendererFactory2, public loadingController: LoadingController) {
    this.renderer = rendererFactory.createRenderer(null, null);
  }
  getTokens(userform) {
    return this.http.get('https://sunglow-jackal-9292.twil.io/video-token?identity=' + userform.username + '&room=' + userform.roomId)
  }
  async presentLoading() {
    this.loading = await this.loadingController.create({
      cssClass: 'my-custom-class',
      message: 'Please wait...',
      duration: 5000
    });
    await this.loading.present();

  }

  async DismissLoading() {
    if (this.loading) { // Added this condition
      await this.loading.dismiss();
    }

    console.log('Loading dismissed!');
  }
  getToken(username): Observable<any> {
    return this.http.post('/abc', { uid: 'ashish' });
  }
  mute() {
    this.roomObj.localParticipant.audioTracks.forEach(function (
      audioTrack
    ) {
      audioTrack.track.disable();
    });
    this.microphone = false;
  }
  unmute() {
    this.roomObj.localParticipant.audioTracks.forEach(function (
      audioTrack
    ) {
      audioTrack.track.enable();
    });
    this.microphone = true;
  }
  connectToRoom(accessToken: string, options): void {
    let trackData: any
    connect(accessToken, options).then(room => {
      this.roomObj = room;
      if (!this.previewing && options['video']) {
        this.startLocalVideo();
        this.previewing = true;
      }
      this.roomParticipants = room.participants;
      room.participants.forEach(participant => {
        this.attachParticipantTracks(participant);
      });
      room.on('participantDisconnected', (participant) => {
        this.detachTracks(participant);
      });
      room.on('participantConnected', (participant) => {
        this.roomParticipants = room.participants;
        this.attachParticipantTracks(participant);
        participant.on('trackPublished', (track) => {
          trackData = track
          const element = trackData.attach();
          this.renderer.data.id = trackData.sid;
          this.renderer.setStyle(element, 'height', '100%');
          this.renderer.setStyle(element, 'max-width', '100%');
          this.renderer.appendChild(this.remoteVideo.nativeElement, element);
        });
      });
      room.on('trackPublished', (track, participant) => {
        this.attachTracks([track]);
      });
      room.on('trackUnsubscribed', track => {
        this.detachTracks([track]);
      });
      room.once('disconnected', room => {
        room.localParticipant.tracks.forEach(track => {
          track.track.stop();
          const attachedElements = track.track.detach();
          attachedElements.forEach(element => element.remove());
          room.localParticipant.videoTracks.forEach(video => {
            const trackConst = [video][0].track;
            trackConst.stop(); // <- error
            trackConst.detach().forEach(element => element.remove());
            room.localParticipant.unpublishTrack(trackConst);
          });
          let element = this.remoteVideo.nativeElement;
          while (element.firstChild) {
            element.removeChild(element.firstChild);
          }
          let localElement = this.localVideo.nativeElement;
          while (localElement.firstChild) {
            localElement.removeChild(localElement.firstChild);
          }
          this.router.navigate(['thanks']);
        });
      });
    }, (error) => {
      alert(error.message);
    });
  }
  attachParticipantTracks(participant): void {
    participant.tracks.forEach(part => {
      this.trackPublished(part);
    });
  }
  trackPublished(publication) {
    if (publication.isSubscribed)
      this.attachTracks(publication.track);
    if (!publication.isSubscribed)
      publication.on('subscribed', track => {
        this.attachTracks(track);
      });
  }
  attachTracks(tracks) {
    const element = tracks.attach();
    this.renderer.data.id = tracks.sid;
    this.renderer.setStyle(element, 'height', '100%');
    this.renderer.setStyle(element, 'max-width', '100%');
    this.renderer.appendChild(this.remoteVideo.nativeElement, element);
  }
  startLocalVideo(): void {
    this.roomObj.localParticipant.videoTracks.forEach(publication => {
      const element = publication.track.attach();
      // this.renderer.data.id = publication.track.sid;
      this.renderer.data.id = 'SKd5c9f75c578fac0cbc642856ff0d5627';
      this.renderer.setStyle(element, 'width', '25%');
      this.renderer.appendChild(this.localVideo, element);
    })
  }
  detachTracks(tracks): void {
    tracks.tracks.forEach(track => {
      let element = this.remoteVideo.nativeElement;
      while (element.firstChild) {
        element.removeChild(element.firstChild);
      }
    });
  }
}
