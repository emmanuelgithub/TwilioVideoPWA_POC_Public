import { Component, ElementRef, Renderer2, RendererFactory2, ViewChild } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { TwilioService } from '../common/twillio.service';
import { connect } from 'twilio-video';
import { BehaviorSubject } from 'rxjs';
declare let window: any;

let newVariable: any;
@Component({
  selector: 'app-home',
  templateUrl: 'home.page.html',
  styleUrls: ['home.page.scss'],
})
export class HomePage {

  @ViewChild('localVideo', { static: false }) localVideo: ElementRef;
  @ViewChild('remoteVideo', { static: false, read: ElementRef }) remoteVideo: ElementRef;
  room_name;
  access_tokan;
  app_id;
  microphone = true

  newVariable = window.navigator;

  userForm: {
    username: '',
    roomId: Number,
    token: ''
  }
  previewing: boolean;
  msgSubject = new BehaviorSubject("");
  roomObj: any;
  roomParticipants;
  renderer: Renderer2;
  isConnected = false
  constructor(
    private router: Router,
    private route: ActivatedRoute,
    public twilioService: TwilioService,
    private rendererFactory: RendererFactory2) {
    this.userForm = {
      username: '',
      roomId: null,
      token: ''
    }
    this.renderer = rendererFactory.createRenderer(null, null);

  }
  ngOnInit() {
    this.twilioService.localVideo = this.localVideo;
    this.twilioService.remoteVideo = this.remoteVideo;
  }

  startCall() {

    var constraints = { audio: true, video: { width: 1280, height: 720 } };

    navigator.mediaDevices.getUserMedia(constraints)
      .then(function (mediaStream) {
        var video = document.querySelector('video');
        video.srcObject = mediaStream;
        video.onloadedmetadata = function (e) {
          video.play();
        };
      })
      .catch(function (err) { console.log(err.name + ": " + err.message); });

    let data: any
    this.route.params.subscribe(params => {
      this.app_id = params['id'];
      const body = {
        bookingId: this.app_id
      };
      console.log('this.userForm ', this.userForm)
      this.twilioService.getTokens(this.userForm).subscribe(res => {
        console.log('res', res)
        data = res
        if (data.token) {
          this.room_name = '11';
          this.access_tokan = data.token;
          this.connect();
        }
      }, (error) => {
        alert(error.message);
      });
    });
    window.addEventListener('unload', () => {
      this.disconnect();
    })
  }
  disconnect() {
    if (this.roomObj && this.roomObj !== null) {
      this.roomObj.disconnect();
      this.roomObj = null;
    } else this.router.navigate(['thanks']);
  }
  connect() {
    this.twilioService.presentLoading()
    let accessToken = this.access_tokan;
    console.log('accessToken', accessToken)
    this.connectToRoom(accessToken, {
      name: this.room_name,
      audio: true,
      video: { height: 720, frameRate: 24, width: 1280 },
      bandwidthProfile: {
        video: {
          mode: 'collaboration',
          renderDimensions: {
            high: { height: 1080, width: 1980 },
            standard: { height: 720, width: 1280 },
            low: { height: 176, width: 144 }
          }
        }
      },
    })
  }

  connectToRoom(accessToken: string, options): void {
    let trackData: any
    connect(accessToken, options).then(room => {
      this.roomObj = room;
      this.isConnected = true
      if (!this.previewing && options['video']) {
        this.startLocalVideo();
        this.previewing = true;
      }
      this.roomParticipants = room.participants;
      room.participants.forEach(participant => {
        this.attachParticipantTracks(participant);
      });
      room.on('participantDisconnected', (participant) => {
        this.detachTracks(participant);
      });
      room.on('participantConnected', (participant) => {
        this.roomParticipants = room.participants;
        this.attachParticipantTracks(participant);
        participant.on('trackPublished', (track) => {
          trackData = track
          const element = trackData.attach();
          this.renderer.data.id = trackData.sid;
          this.renderer.setStyle(element, 'height', '100%');
          this.renderer.setStyle(element, 'max-width', '100%');
          this.renderer.appendChild(this.remoteVideo.nativeElement, element);
        });
      });
      // When a Participant adds a Track, attach it to the DOM.
      room.on('trackPublished', (track, participant) => {
        this.attachTracks([track]);
      });
      // When a Participant removes a Track, detach it from the DOM.
      room.on('trackUnsubscribed', track => {
        this.detachTracks([track]);
      });
      room.once('disconnected', room => {
        room.localParticipant.tracks.forEach(track => {
          track.track.stop();
          const attachedElements = track.track.detach();
          attachedElements.forEach(element => element.remove());
          room.localParticipant.videoTracks.forEach(video => {
            const trackConst = [video][0].track;
            trackConst.stop(); // <- error
            trackConst.detach().forEach(element => element.remove());
            room.localParticipant.unpublishTrack(trackConst);
          });
          let element = this.remoteVideo.nativeElement;
          while (element.firstChild) {
            element.removeChild(element.firstChild);
          }
          let localElement = this.localVideo.nativeElement;
          while (localElement.firstChild) {
            localElement.removeChild(localElement.firstChild);
          }
          this.router.navigate(['thanks']);
        });
      });
    }, (error) => {
      alert(error.message);
    });
  }

  startLocalVideo(): void {
    this.roomObj.localParticipant.videoTracks.forEach(publication => {
      const element = publication.track.attach();
      this.renderer.data.id = publication.track.sid;
      this.renderer.setStyle(element, 'width', '90%');
      this.renderer.setStyle(element, 'height', '450px');
      this.renderer.appendChild(this.localVideo.nativeElement, element);
    })
  }

  detachTracks(tracks): void {
    tracks.tracks.forEach(track => {
      let element = this.remoteVideo.nativeElement;
      while (element.firstChild) {
        element.removeChild(element.firstChild);
      }
    });
  }

  attachTracks(tracks) {
    const element = tracks.attach();
    this.renderer.data.id = tracks.sid;
    this.renderer.setStyle(element, 'height', '100%');
    this.renderer.setStyle(element, 'max-width', '100%');
    this.renderer.appendChild(this.remoteVideo.nativeElement, element);
  }

  attachParticipantTracks(participant): void {
    participant.tracks.forEach(part => {
      this.trackPublished(part);
    });
  }

  trackPublished(publication) {
    if (publication.isSubscribed)
      this.attachTracks(publication.track);
    if (!publication.isSubscribed)
      publication.on('subscribed', track => {
        this.attachTracks(track);
      });
  }

  mute() {
    this.microphone = false
    this.twilioService.mute();
  }
  unmute() {
    this.microphone = true
    this.twilioService.unmute();
  }
  ngOnDestroy() { this.disconnect(); }
} 
